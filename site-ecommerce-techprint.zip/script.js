let total=0;
function addToCart(name,price){
 const li=document.createElement('li');
 li.textContent=name+' - '+price+' €';
 document.getElementById('cart').appendChild(li);
 total+=price;
 document.getElementById('total').textContent=total;
}