const $ = (s) => document.querySelector(s);
const adsEl = $("#ads");
let currentUser = null;

async function api(url, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Une erreur est survenue.");
  return data;
}

function openModal(id) {
  $("#" + id).classList.remove("hidden");
}
function closeModal(id) {
  $("#" + id).classList.add("hidden");
}

function updateHeader() {
  $("#loginBtn").classList.toggle("hidden", !!currentUser);
  $("#registerBtn").classList.toggle("hidden", !!currentUser);
  $("#postBtn").classList.toggle("hidden", !currentUser);
  $("#logoutBtn").classList.toggle("hidden", !currentUser);
}

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

function renderAds(ads) {
  $("#count").textContent = `${ads.length} annonce${ads.length > 1 ? "s" : ""}`;
  if (!ads.length) {
    adsEl.innerHTML = `<div class="empty">Aucune annonce trouvée.</div>`;
    return;
  }

  adsEl.innerHTML = ads.map(ad => `
    <article class="card">
      ${ad.image_url ? `<img src="${esc(ad.image_url)}" alt="">` : `<div class="noimg">📦</div>`}
      <div class="card-body">
        <div class="tag">${esc(ad.category)}</div>
        <h3>${esc(ad.title)}</h3>
        <div class="price">${Number(ad.price).toFixed(2)} €</div>
        <p>${esc(ad.description).slice(0, 150)}${ad.description.length > 150 ? "…" : ""}</p>
        <div class="meta">📍 ${esc(ad.city)} · vendeur : ${esc(ad.seller_name)}</div>
      </div>
    </article>
  `).join("");
}

async function loadAds() {
  const params = new URLSearchParams();
  if ($("#search").value.trim()) params.set("q", $("#search").value.trim());
  if ($("#category").value) params.set("category", $("#category").value);
  if ($("#city").value.trim()) params.set("city", $("#city").value.trim());

  try {
    const data = await api("/api/ads?" + params.toString());
    renderAds(data.ads);
  } catch (e) {
    adsEl.innerHTML = `<div class="empty">${esc(e.message)}</div>`;
  }
}

function showAuth(tab = "login") {
  openModal("authModal");
  switchTab(tab);
}

function switchTab(tab) {
  document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
  $("#loginForm").classList.toggle("hidden", tab !== "login");
  $("#registerForm").classList.toggle("hidden", tab !== "register");
  $("#authMsg").textContent = "";
}

$("#loginBtn").onclick = () => showAuth("login");
$("#registerBtn").onclick = () => showAuth("register");
$("#heroPostBtn").onclick = () => currentUser ? openModal("postModal") : showAuth("login");
$("#postBtn").onclick = () => openModal("postModal");
$("#logoutBtn").onclick = async () => {
  await api("/api/logout", { method: "POST" });
  currentUser = null;
  updateHeader();
};

document.querySelectorAll(".tab").forEach(b => b.onclick = () => switchTab(b.dataset.tab));
document.querySelectorAll("[data-close]").forEach(b => b.onclick = () => closeModal(b.dataset.close));
$("#searchBtn").onclick = loadAds;
$("#search").addEventListener("keydown", e => { if (e.key === "Enter") loadAds(); });
$("#city").addEventListener("keydown", e => { if (e.key === "Enter") loadAds(); });

$("#loginForm").onsubmit = async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  try {
    const data = await api("/api/login", {
      method: "POST",
      body: JSON.stringify(Object.fromEntries(form))
    });
    currentUser = data.user;
    updateHeader();
    closeModal("authModal");
    e.target.reset();
  } catch (err) {
    $("#authMsg").textContent = err.message;
  }
};

$("#registerForm").onsubmit = async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  try {
    const data = await api("/api/register", {
      method: "POST",
      body: JSON.stringify(Object.fromEntries(form))
    });
    currentUser = data.user;
    updateHeader();
    closeModal("authModal");
    e.target.reset();
  } catch (err) {
    $("#authMsg").textContent = err.message;
  }
};

$("#postForm").onsubmit = async (e) => {
  e.preventDefault();
  const form = new FormData(e.target);
  try {
    await api("/api/ads", {
      method: "POST",
      body: JSON.stringify(Object.fromEntries(form))
    });
    e.target.reset();
    closeModal("postModal");
    loadAds();
  } catch (err) {
    $("#postMsg").textContent = err.message;
  }
};

(async function init() {
  try {
    const data = await api("/api/me");
    currentUser = data.user;
  } catch {}
  updateHeader();
  loadAds();
})();