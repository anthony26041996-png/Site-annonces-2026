# Site-annonces

Application d'annonces en Node.js / Express / PostgreSQL.

## Déploiement Render

- Language: Node
- Branch: main
- Root Directory: laisser vide
- Build Command: `npm install`
- Start Command: `npm start`
- Plan: Free

Variables d'environnement nécessaires:

- `DATABASE_URL` : URL de la base PostgreSQL Render
- `JWT_SECRET` : clé secrète longue
- `NODE_ENV=production`

Le port est fourni automatiquement par Render via `PORT`.
